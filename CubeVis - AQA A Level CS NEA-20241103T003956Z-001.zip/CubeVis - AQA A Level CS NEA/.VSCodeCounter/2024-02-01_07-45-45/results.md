# Summary

Date : 2024-02-01 07:45:45

Directory /Users/nahlfarhan/Desktop/NEA/Comp Sci/CubeVis

Total : 20 files,  1050 codes, 257 comments, 87 blanks, all 1394 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Python | 13 | 847 | 250 | 82 | 1,179 |
| HTML | 7 | 203 | 7 | 5 | 215 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 20 | 1,050 | 257 | 87 | 1,394 |
| . (Files) | 7 | 519 | 203 | 40 | 762 |
| Website | 13 | 531 | 54 | 47 | 632 |
| Website (Files) | 6 | 328 | 47 | 42 | 417 |
| Website/templates | 7 | 203 | 7 | 5 | 215 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)