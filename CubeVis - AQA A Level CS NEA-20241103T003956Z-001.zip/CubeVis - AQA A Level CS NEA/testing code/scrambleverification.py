# from .cube import *
# from ._scramblegen import *
# # from cube import *
# # from _scramblegen import *
# # from views import s

# current_cube = scramble(current_scramble)
# #print('the scramble', stringscramble(current_scramble))

# def return_scanned_cube():
#     from .colourscanning import scanned_cube
#     for i in range (len(scanned_cube)):
#         print(scanned_cube[i][4], ':', scanned_cube[i])
#     return scanned_cube

# def verifiying_scanned_cube(scanned_cube):
#     if scanned_cube == current_cube:
#         print('Cube scrambled correctly')
#         return True
#     else:
#         return False
