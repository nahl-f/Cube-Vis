# Details

Date : 2024-02-01 07:45:45

Directory /Users/nahlfarhan/Desktop/NEA/Comp Sci/CubeVis

Total : 20 files,  1050 codes, 257 comments, 87 blanks, all 1394 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [ notes_classes.py](/%20notes_classes.py) | Python | 0 | 24 | 3 | 27 |
| [Website/__init__.py](/Website/__init__.py) | Python | 29 | 3 | 12 | 44 |
| [Website/_scramblegen.py](/Website/_scramblegen.py) | Python | 30 | 10 | 5 | 45 |
| [Website/auth.py](/Website/auth.py) | Python | 58 | 5 | 9 | 72 |
| [Website/cube.py](/Website/cube.py) | Python | 185 | 24 | 7 | 216 |
| [Website/models.py](/Website/models.py) | Python | 6 | 2 | 3 | 11 |
| [Website/templates/base.html](/Website/templates/base.html) | HTML | 82 | 7 | 1 | 90 |
| [Website/templates/home.html](/Website/templates/home.html) | HTML | 18 | 0 | 1 | 19 |
| [Website/templates/login.html](/Website/templates/login.html) | HTML | 36 | 0 | 0 | 36 |
| [Website/templates/notation.html](/Website/templates/notation.html) | HTML | 5 | 0 | 1 | 6 |
| [Website/templates/scramble.html](/Website/templates/scramble.html) | HTML | 14 | 0 | 2 | 16 |
| [Website/templates/signup.html](/Website/templates/signup.html) | HTML | 39 | 0 | 0 | 39 |
| [Website/templates/timer.html](/Website/templates/timer.html) | HTML | 9 | 0 | 0 | 9 |
| [Website/views.py](/Website/views.py) | Python | 20 | 3 | 6 | 29 |
| [colourdetect.py](/colourdetect.py) | Python | 32 | 2 | 4 | 38 |
| [colourdetection.py](/colourdetection.py) | Python | 85 | 3 | 8 | 96 |
| [copycube.py](/copycube.py) | Python | 188 | 147 | 10 | 345 |
| [finalcubecopy.py](/finalcubecopy.py) | Python | 183 | 16 | 6 | 205 |
| [main.py](/main.py) | Python | 4 | 0 | 4 | 8 |
| [test.py](/test.py) | Python | 27 | 11 | 5 | 43 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)